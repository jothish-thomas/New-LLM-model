# LLM From Scratch

A minimal, character-level GPT (transformer decoder) in PyTorch. Small enough to
read in one sitting, real enough to train and generate text. Based on the
architecture of Andrej Karpathy's nanoGPT.

## Files

| File               | What it does                                             |
|--------------------|----------------------------------------------------------|
| `model.py`         | The GPT model: attention, feedforward, blocks, generate  |
| `data.py`          | Character tokenizer + batching                           |
| `train.py`         | Training loop; saves `gpt_model.pt` and `vocab.pt`       |
| `generate.py`      | Loads the trained model and produces text                |
| `download_data.py` | Fetches a sample dataset (Tiny Shakespeare)              |
| `requirements.txt` | Dependencies                                             |

## Quick start

```bash
# 1. Install dependencies
pip install -r requirements.txt

# 2. Get some training text (or drop in your own input.txt)
python download_data.py

# 3. Train
python train.py

# 4. Generate
python generate.py --tokens 1000 --prompt "ROMEO:"
```

## Using your own data

Replace `input.txt` with any plain-text file (`.txt`, UTF-8). Use text you have
the right to train on — public-domain works (Project Gutenberg) or openly
licensed datasets are safe choices. Keep personal or confidential data out.

## Running on Kaggle / Colab

Set the runtime to GPU:
- **Colab:** Runtime → Change runtime type → GPU
- **Kaggle:** Settings → Accelerator → GPU

Then upload these files (or clone them) and run the same commands. On a free T4
GPU, 5000 iterations takes only a few minutes. Save `gpt_model.pt` before the
session disconnects (on Kaggle it lives in `/kaggle/working/`).

## Tuning

The dials are all at the top of `train.py`:

- `n_embd`, `n_head`, `n_layer` — bigger = more capable but slower
- `block_size` — how far back the model can "see"
- `batch_size` — raise it if you have GPU memory to spare
- `max_iters` — train longer for lower loss (watch val loss to avoid overfitting)

## Where to go next

- Swap the character tokenizer for subword BPE (`tiktoken` or HuggingFace `tokenizers`)
- Train on a much larger corpus
- Add modern improvements: RoPE positional encoding, RMSNorm, SwiGLU
- Scale to multiple GPUs, then explore fine-tuning / instruction tuning
