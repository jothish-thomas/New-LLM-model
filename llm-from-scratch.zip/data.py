"""
Character-level tokenizer and data batching utilities.
"""

import torch


class CharTokenizer:
    """Simplest possible tokenizer: one integer per character."""

    def __init__(self, text):
        chars = sorted(list(set(text)))
        self.vocab_size = len(chars)
        self.stoi = {ch: i for i, ch in enumerate(chars)}
        self.itos = {i: ch for i, ch in enumerate(chars)}

    def encode(self, s):
        return [self.stoi[c] for c in s]

    def decode(self, tokens):
        return ''.join(self.itos[i] for i in tokens)


def load_data(path, tokenizer, train_split=0.9):
    with open(path, 'r', encoding='utf-8') as f:
        text = f.read()
    data = torch.tensor(tokenizer.encode(text), dtype=torch.long)
    n = int(train_split * len(data))
    return data[:n], data[n:]


def get_batch(data, block_size, batch_size, device):
    ix = torch.randint(len(data) - block_size, (batch_size,))
    x = torch.stack([data[i:i + block_size] for i in ix])
    y = torch.stack([data[i + 1:i + block_size + 1] for i in ix])
    return x.to(device), y.to(device)
