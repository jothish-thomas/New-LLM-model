"""
Download a sample dataset (Tiny Shakespeare) to train on.

Usage:
    python download_data.py

Creates input.txt (~1 MB of public-domain Shakespeare).
You can replace input.txt with any plain-text file you have the right to use.
"""

import urllib.request

URL = "https://raw.githubusercontent.com/karpathy/char-rnn/master/data/tinyshakespeare/input.txt"


def main():
    print("Downloading Tiny Shakespeare...")
    urllib.request.urlretrieve(URL, "input.txt")
    with open("input.txt", "r", encoding="utf-8") as f:
        text = f.read()
    print(f"Done. input.txt = {len(text):,} characters")


if __name__ == '__main__':
    main()
