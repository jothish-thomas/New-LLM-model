"""
Train the GPT model.

Usage:
    python train.py

Expects a plain-text file named input.txt in the same directory.
Saves the trained weights to gpt_model.pt and the vocab to vocab.pt.
"""

import torch

from model import GPT
from data import CharTokenizer, load_data, get_batch

# ------------------------------------------------------------------
# Hyperparameters — tune these
# ------------------------------------------------------------------
batch_size = 32        # sequences processed in parallel
block_size = 128       # context length (max tokens the model can see)
n_embd = 256           # embedding / channel size
n_head = 8             # number of attention heads
n_layer = 6            # number of transformer blocks
dropout = 0.2          # regularization
learning_rate = 3e-4
max_iters = 5000
eval_interval = 500    # how often to print/estimate loss
eval_iters = 200       # batches used to estimate loss
seed = 1337
# ------------------------------------------------------------------

torch.manual_seed(seed)
device = 'cuda' if torch.cuda.is_available() else 'cpu'
print(f"Using device: {device}")


@torch.no_grad()
def estimate_loss(model, train_data, val_data):
    """Average loss over a few batches for a smoother reading than a single batch."""
    out = {}
    model.eval()
    for split, data in [('train', train_data), ('val', val_data)]:
        losses = torch.zeros(eval_iters)
        for k in range(eval_iters):
            xb, yb = get_batch(data, block_size, batch_size, device)
            _, loss = model(xb, yb)
            losses[k] = loss.item()
        out[split] = losses.mean().item()
    model.train()
    return out


def main():
    # --- load text and build tokenizer ---
    with open('input.txt', 'r', encoding='utf-8') as f:
        text = f.read()
    tokenizer = CharTokenizer(text)
    print(f"Vocab size: {tokenizer.vocab_size}")

    train_data, val_data = load_data('input.txt', tokenizer)
    print(f"Train tokens: {len(train_data):,} | Val tokens: {len(val_data):,}")

    # --- build model ---
    model = GPT(
        vocab_size=tokenizer.vocab_size,
        n_embd=n_embd,
        n_head=n_head,
        n_layer=n_layer,
        block_size=block_size,
        dropout=dropout,
        device=device,
    ).to(device)

    n_params = sum(p.numel() for p in model.parameters())
    print(f"Model parameters: {n_params/1e6:.2f}M")

    optimizer = torch.optim.AdamW(model.parameters(), lr=learning_rate)

    # --- training loop ---
    for it in range(max_iters):
        if it % eval_interval == 0 or it == max_iters - 1:
            losses = estimate_loss(model, train_data, val_data)
            print(f"iter {it:5d} | train loss {losses['train']:.4f} | val loss {losses['val']:.4f}")

        xb, yb = get_batch(train_data, block_size, batch_size, device)
        _, loss = model(xb, yb)
        optimizer.zero_grad(set_to_none=True)
        loss.backward()
        optimizer.step()

    # --- save ---
    torch.save(model.state_dict(), 'gpt_model.pt')
    torch.save(
        {
            'stoi': tokenizer.stoi,
            'itos': tokenizer.itos,
            'vocab_size': tokenizer.vocab_size,
            'config': {
                'n_embd': n_embd, 'n_head': n_head, 'n_layer': n_layer,
                'block_size': block_size, 'dropout': dropout,
            },
        },
        'vocab.pt',
    )
    print("Saved gpt_model.pt and vocab.pt")


if __name__ == '__main__':
    main()
