"""
Generate text from a trained model.

Usage:
    python generate.py
    python generate.py --tokens 1000 --prompt "ROMEO:"

Requires gpt_model.pt and vocab.pt (produced by train.py).
"""

import argparse
import torch

from model import GPT


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--tokens', type=int, default=500, help='number of tokens to generate')
    parser.add_argument('--prompt', type=str, default='', help='optional starting text')
    args = parser.parse_args()

    device = 'cuda' if torch.cuda.is_available() else 'cpu'

    # --- load vocab + config ---
    meta = torch.load('vocab.pt', map_location=device)
    stoi, itos = meta['stoi'], meta['itos']
    cfg = meta['config']

    encode = lambda s: [stoi[c] for c in s]
    decode = lambda l: ''.join(itos[i] for i in l)

    # --- rebuild model and load weights ---
    model = GPT(
        vocab_size=meta['vocab_size'],
        n_embd=cfg['n_embd'],
        n_head=cfg['n_head'],
        n_layer=cfg['n_layer'],
        block_size=cfg['block_size'],
        dropout=cfg['dropout'],
        device=device,
    ).to(device)
    model.load_state_dict(torch.load('gpt_model.pt', map_location=device))
    model.eval()

    # --- prepare context ---
    if args.prompt:
        context = torch.tensor([encode(args.prompt)], dtype=torch.long, device=device)
    else:
        context = torch.zeros((1, 1), dtype=torch.long, device=device)

    out = model.generate(context, max_new_tokens=args.tokens)[0].tolist()
    print(decode(out))


if __name__ == '__main__':
    main()
